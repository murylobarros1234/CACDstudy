#!/usr/bin/env python3
"""CACD Study – plataforma com login, perfis, cursos, caderno digital e flashcards.
Uso:  python3 app/plataforma.py   -> http://localhost:8765
Variáveis: PORT, HOST, CACD_DB, MASTER_EMAIL, SECURE_COOKIE=1 (atrás de HTTPS), ANTHROPIC_API_KEY, CLAUDE_MODEL
O PRIMEIRO cadastro (ou o e-mail em MASTER_EMAIL) vira Master."""
import datetime, json, os, random, re, shutil, sqlite3, secrets, hashlib, hmac, time, sys, tempfile, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DB_PATH = os.environ.get('CACD_DB', os.path.join(ROOT, 'data', 'cacd.db'))
STATIC = os.path.join(os.path.dirname(__file__), 'static2')
WA, FREE, DAY = '5564981614321', 5, 86400
MP_BASE = os.environ.get('MP_API_BASE', 'https://api.mercadopago.com')
PRECO = round(float(os.environ.get('PRECO', '39.90')), 2)
DIAS_PIX = 30
JANELA = 48 * 3600   # o plano grátis renova a cada 48h, contadas a partir do primeiro uso
MODEL = os.environ.get('CLAUDE_MODEL', 'claude-sonnet-5-5')
MATERIAS = ['Língua Portuguesa', 'Língua Inglesa', 'História do Brasil', 'História Mundial', 'Geografia',
            'Política Internacional', 'Economia', 'Direito', 'Língua Francesa (2ª fase)', 'Língua Espanhola (2ª fase)']
SCHEMA = '''
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, nome TEXT, email TEXT UNIQUE, pw TEXT, role TEXT DEFAULT 'iniciante',
  acesso_ate INTEGER DEFAULT 0, criado_em INTEGER, ultimo_login INTEGER);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER, exp INTEGER);
CREATE TABLE IF NOT EXISTS cursos(id INTEGER PRIMARY KEY, materia TEXT, titulo TEXT, descricao TEXT, url TEXT, ordem INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS u_attempts(id INTEGER PRIMARY KEY, user_id INTEGER, item_id INTEGER, resposta TEXT, correta INTEGER, tempo_ms INTEGER, em INTEGER);
CREATE TABLE IF NOT EXISTS notebooks(id INTEGER PRIMARY KEY, user_id INTEGER, nome TEXT, materia TEXT);
CREATE TABLE IF NOT EXISTS blocks(id INTEGER PRIMARY KEY, notebook_id INTEGER, user_id INTEGER, parent_id INTEGER, pos INTEGER DEFAULT 0, texto TEXT DEFAULT '', aberto INTEGER DEFAULT 1, importante INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS agenda(id INTEGER PRIMARY KEY, user_id INTEGER, titulo TEXT, data TEXT, inicio TEXT, fim TEXT, categoria TEXT DEFAULT 'estudo', notas TEXT DEFAULT '', repete INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS cards(id INTEGER PRIMARY KEY, user_id INTEGER, deck TEXT, frente TEXT, verso TEXT, origem TEXT, block_id INTEGER, item_id INTEGER,
  reps INTEGER DEFAULT 0, ease REAL DEFAULT 2.5, ivl INTEGER DEFAULT 0, due INTEGER DEFAULT 0, lapsos INTEGER DEFAULT 0, criado_em INTEGER);
CREATE TABLE IF NOT EXISTS u_reviews(id INTEGER PRIMARY KEY, user_id INTEGER, card_id INTEGER, nota INTEGER, em INTEGER);
CREATE TABLE IF NOT EXISTS pagamentos(id INTEGER PRIMARY KEY, user_id INTEGER, mp_id TEXT UNIQUE, valor REAL, status TEXT DEFAULT 'pendente', criado_em INTEGER, pago_em INTEGER, qr_code TEXT, qr_src TEXT, expira_em INTEGER);
CREATE INDEX IF NOT EXISTS ix_blocks_nb ON blocks(notebook_id); CREATE INDEX IF NOT EXISTS ix_cards_u ON cards(user_id,due);
'''
FAILS = {}


def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def rows(c, sql, *a):
    return [dict(r) for r in c.execute(sql, a).fetchall()]


def hash_pw(pw):
    s = secrets.token_hex(16)
    return 'scrypt$%s$%s' % (s, hashlib.scrypt(pw.encode(), salt=s.encode(), n=16384, r=8, p=1, dklen=32).hex())


def check_pw(pw, stored):
    try:
        _, s, h = stored.split('$')
        return hmac.compare_digest(hashlib.scrypt(pw.encode(), salt=s.encode(), n=16384, r=8, p=1, dklen=32).hex(), h)
    except Exception:
        return False


def role_label(u):
    if u['role'] == 'master': return 'Master'
    if u['role'] == 'quarto': return 'Quarto-secretário' if u['acesso_ate'] > time.time() else 'Quarto-secretário (acesso expirado)'
    return 'Iniciante CACD'


def unlimited(u):
    return u['role'] == 'master' or (u['role'] == 'quarto' and u['acesso_ate'] > time.time())


def janela_ativa(u):
    ws = u.get('janela_ini') or 0
    return ws if ws and time.time() < ws + JANELA else 0


def usage(c, u):
    ws = janela_ativa(u)
    if not ws: return 0, 0
    q = c.execute('SELECT COUNT(*) FROM u_attempts WHERE user_id=? AND em>=?', (u['id'], ws)).fetchone()[0]
    r = c.execute('SELECT COUNT(*) FROM u_reviews WHERE user_id=? AND em>=?', (u['id'], ws)).fetchone()[0]
    return q, r


def start_window(c, u):
    if unlimited(u) or janela_ativa(u): return
    now = int(time.time()); c.execute('UPDATE users SET janela_ini=? WHERE id=?', (now, u['id'])); u['janela_ini'] = now


def premium_only(me):
    return None if unlimited(me) else {'premium': True, 'erro': 'A revisão automática é um recurso exclusivo para assinantes.'}


def allowed(c, u, kind):
    if unlimited(u): return True
    q, r = usage(c, u)
    return (q if kind == 'q' else r) < FREE


def current_key(c, item_id):
    r = c.execute("SELECT * FROM answer_keys WHERE item_id=? AND vigente=1 AND versao IN ('manual','definitivo') "
                  "ORDER BY CASE versao WHEN 'manual' THEN 0 ELSE 1 END, id DESC LIMIT 1", (item_id,)).fetchone()
    return dict(r) if r else None


def item_row(c, item_id):
    r = c.execute('''SELECT i.id,i.rotulo,i.disciplina,i.enunciado,i.gabarito_status,i.needs_review,i.review_reason,i.page,e.ano,g.texto_base,g.comando
                     FROM items i JOIN exams e ON e.id=i.exam_id JOIN question_groups g ON g.id=i.group_id WHERE i.id=?''', (item_id,)).fetchone()
    return dict(r) if r else None


def sm2(card, nota):
    e, v, l = card['ease'], card['ivl'], 0
    if nota == 0: e, v, l = max(1.3, e - .2), 0, 1
    elif nota == 1: v, e = max(1, round(v * 1.2)), max(1.3, e - .15)
    elif nota == 2: v = 1 if card['reps'] == 0 else 3 if card['reps'] == 1 else round(v * e)
    else: v, e = (3 if card['reps'] == 0 else max(4, round(v * e * 1.3))), e + .15
    return e, v, l


def simple_cards(it, resp):
    nome = 'CERTO' if resp == 'C' else 'ERRADO'
    return [(f"[{it['disciplina']} · TPS {it['ano']}] Julgue como CERTO ou ERRADO:\n{it['enunciado']}",
             f"{nome} (gabarito oficial definitivo)")]


def ai_cards(it, resp):
    key = os.environ.get('ANTHROPIC_API_KEY')
    if not key: return None
    nome = 'CERTO' if resp == 'C' else 'ERRADO'
    prompt = (f"Você prepara flashcards para o concurso de Diplomata (CACD/IRBr). Item do TPS ({it['ano']}, {it['disciplina']}).\n"
              f"TEXTO-BASE: {(it['texto_base'] or '')[:5000]}\nCOMANDO: {it['comando']}\nITEM: {it['enunciado']}\n"
              f"GABARITO OFICIAL DEFINITIVO: {nome}. Não questione o gabarito.\n"
              "Crie de 4 a 5 flashcards que destrinchem o conhecimento necessário para julgar o item. Cada cartão testa UMA ideia; "
              "a frente é pergunta ou termo autossuficiente; o verso é resposta objetiva (até 3 linhas) em português. "
              "Use só fatos de que tem certeza; sem inventar datas, artigos, citações ou autores; se não tiver certeza, omita o cartão. "
              'Responda somente com JSON: [{"f":"frente","v":"verso"}]')
    body = json.dumps({'model': MODEL, 'max_tokens': 1200, 'messages': [{'role': 'user', 'content': prompt}]}).encode()
    req = urllib.request.Request('https://api.anthropic.com/v1/messages', data=body, headers={
        'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01'})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            data = json.load(r)
        txt = ''.join(b.get('text', '') for b in data.get('content', []) if b.get('type') == 'text')
        arr = json.loads(re.search(r'\[.*\]', txt, re.S).group(0))
        return [(str(a['f']), str(a['v'])) for a in arr if a.get('f') and a.get('v')][:5] or None
    except Exception:
        return None


def make_cards(c, u, item_id, resp, force=False):
    """Cria flashcards do item: com IA (4–5) se houver chave; senão 1 cartão simples. Retorna (qtd, modo)."""
    if not force and c.execute('SELECT 1 FROM cards WHERE user_id=? AND item_id=?', (u['id'], item_id)).fetchone():
        return 0, 'existentes'
    it = item_row(c, item_id)
    cards, modo = ai_cards(it, resp), 'ia'
    if not cards: cards, modo = simple_cards(it, resp), 'simples'
    c.execute('DELETE FROM cards WHERE user_id=? AND item_id=?', (u['id'], item_id))
    for f, v in cards:
        c.execute('INSERT INTO cards(user_id,deck,frente,verso,origem,item_id,criado_em) VALUES(?,?,?,?,?,?,?)',
                  (u['id'], 'Erros do TPS', f, v, 'IA' if modo == 'ia' else 'auto', item_id, int(time.time())))
    return len(cards), modo


def sync_block_card(c, u, nb, bid, texto):
    """Estilo RemNote: 'frente :: verso' vira flashcard automaticamente."""
    c.execute("DELETE FROM cards WHERE user_id=? AND block_id=? AND origem='caderno'", (u['id'], bid))
    if '::' in texto:
        f, v = [x.strip() for x in texto.split('::', 1)]
        if f and v:
            c.execute('INSERT INTO cards(user_id,deck,frente,verso,origem,block_id,criado_em) VALUES(?,?,?,?,?,?,?)',
                      (u['id'], nb['nome'], f, v, 'caderno', bid, int(time.time())))


def siblings(c, nb, parent):
    return [r['id'] for r in c.execute('SELECT id FROM blocks WHERE notebook_id=? AND parent_id IS ? ORDER BY pos,id', (nb, parent))]


def renumber(c, ids):
    for i, b in enumerate(ids): c.execute('UPDATE blocks SET pos=? WHERE id=?', (i, b))


def descendants(c, bid):
    out, stack = [], [bid]
    while stack:
        x = stack.pop(); out.append(x)
        stack += [r['id'] for r in c.execute('SELECT id FROM blocks WHERE parent_id=?', (x,))]
    return out


def mp_on():
    return bool(os.environ.get('MP_ACCESS_TOKEN'))


def mp_req(method, path, body=None, idem=None):
    h = {'Authorization': 'Bearer ' + os.environ['MP_ACCESS_TOKEN'], 'Content-Type': 'application/json'}
    if idem: h['X-Idempotency-Key'] = idem
    rq = urllib.request.Request(MP_BASE + path, data=json.dumps(body).encode() if body is not None else None, method=method, headers=h)
    with urllib.request.urlopen(rq, timeout=30) as r: return json.load(r)


def liberar(c, uid, dias):
    t = c.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
    base = max(time.time(), t['acesso_ate'] or 0)
    c.execute("UPDATE users SET role=CASE WHEN role='master' THEN 'master' ELSE 'quarto' END, acesso_ate=? WHERE id=?", (int(base + dias * DAY), uid))


def confirmar_pagamento(c, pg):
    """Consulta o Mercado Pago (nunca confia no aviso recebido) e libera o acesso UMA vez se estiver aprovado, com valor e referência corretos."""
    if pg['status'] == 'aprovado' or not pg['mp_id'] or not mp_on(): return pg['status']
    try: p = mp_req('GET', '/v1/payments/' + str(pg['mp_id']))
    except Exception: return pg['status']
    st = p.get('status')
    if st == 'approved':
        if abs(float(p.get('transaction_amount') or 0) - float(pg['valor'])) > 0.004 or p.get('external_reference') != f"cacd-{pg['id']}":
            c.execute("UPDATE pagamentos SET status='divergente' WHERE id=?", (pg['id'],)); c.commit(); return 'divergente'
        if c.execute("UPDATE pagamentos SET status='aprovado', pago_em=? WHERE id=? AND status!='aprovado'", (int(time.time()), pg['id'])).rowcount == 1:
            liberar(c, pg['user_id'], DIAS_PIX)
        c.commit(); return 'aprovado'
    if st in ('rejected', 'cancelled', 'expired'):
        c.execute('UPDATE pagamentos SET status=? WHERE id=?', ('expirado' if st == 'expired' else 'recusado', pg['id'])); c.commit(); return 'recusado'
    return 'pendente'


def assinatura_valida(headers, data_id):
    segredo = os.environ.get('MP_WEBHOOK_SECRET')
    if not segredo: return True   # sem segredo configurado, a segurança vem de consultar o pagamento na API
    sig = headers.get('x-signature') or ''
    partes = dict(x.strip().split('=', 1) for x in sig.split(',') if '=' in x)
    if not partes.get('ts') or not partes.get('v1'): return False
    manifest = f"id:{data_id};request-id:{headers.get('x-request-id') or ''};ts:{partes['ts']};"
    return hmac.compare_digest(hmac.new(segredo.encode(), manifest.encode(), hashlib.sha256).hexdigest(), partes['v1'])


def ancestors(byid, b):
    out, p = [], b['parent_id']
    while p and p in byid:
        out.insert(0, byid[p]['texto']); p = byid[p]['parent_id']
    return [t for t in out if t.strip()]


def dfs_order(bl):
    kids = {}
    for b in bl: kids.setdefault(b['parent_id'], []).append(b)
    out = []
    def walk(pid):
        for b in kids.get(pid, []): out.append(b); walk(b['id'])
    walk(None)
    return out


def smart_card(texto, ctx):
    """Cria frente/verso a partir de um trecho do caderno (heurística local, sem IA). Retorna (frente, verso, modo)."""
    t = ' '.join(texto.split()); tema = ctx[-1] if ctx else None
    if '::' in t:
        f, v = [x.strip() for x in t.split('::', 1)]
        if f and v: return f, v, 'caderno'
    m = re.match(r'^(.{3,90}?)\s*(?::|—|–| - )\s+(.{3,})$', t)
    if m: return m.group(1).strip(), m.group(2).strip(), 'definição'
    m = re.match(r'^(.{3,80}?)\s+(é|são|foi|foram|significa|consiste em|refere-se a)\s+(.{5,})$', t)
    if m: return f"Explique: {m.group(1).strip()}", t, 'definição'
    words = re.findall(r"[\wÀ-ÿ]+", t)
    cand = [w for w in words if re.fullmatch(r'\d{3,4}', w)] or \
           [w for i, w in enumerate(words) if i > 0 and w[:1].isupper() and len(w) >= 4] or \
           sorted([w for w in words if len(w) >= 6], key=len, reverse=True)
    if cand and len(words) >= 4:
        k = cand[0]; f = re.sub(r'\b%s\b' % re.escape(k), '_____', t, count=1)
        return (f"[{tema}] " if tema else '') + f, f"{k}\n\n{t}", 'lacuna'
    return f"Lembre-se: {tema or 'tópico do caderno'}", t, 'resumo'


def week_events(c, uid, de, ate):
    d0, d1 = datetime.date.fromisoformat(de), datetime.date.fromisoformat(ate)
    out = []
    for r in c.execute('SELECT * FROM agenda WHERE user_id=?', (uid,)):
        r = dict(r); base = datetime.date.fromisoformat(r['data'])
        if not r['repete']:
            if d0 <= base <= d1: r['data_base'] = r['data']; out.append(r)
        else:
            d = max(d0, base)
            d += datetime.timedelta(days=(-(d - base).days) % 7)
            while d <= d1:
                o = dict(r); o['data_base'] = r['data']; o['data'] = d.isoformat(); out.append(o); d += datetime.timedelta(days=7)
    return sorted(out, key=lambda x: (x['data'], x['inicio']))


def agenda_clean(d):
    t = str(d.get('titulo', '')).strip()
    try: datetime.date.fromisoformat(str(d.get('data', '')))
    except ValueError: return None, 'Data inválida.'
    i, f = str(d.get('inicio', '')), str(d.get('fim', ''))
    if not t: return None, 'Informe o título.'
    if not (re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d', i) and re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d', f)): return None, 'Horário inválido (use HH:MM).'
    if f <= i: return None, 'O horário final deve ser depois do inicial.'
    cat = d.get('categoria') if d.get('categoria') in ('estudo', 'trabalho', 'compromisso', 'outro') else 'estudo'
    return (t[:120], str(d['data']), i, f, cat, str(d.get('notas', ''))[:1000], 1 if d.get('repete') else 0), None


def dashboard(c, u):
    rs = c.execute('SELECT a.item_id,a.correta,a.tempo_ms,a.em,i.disciplina,e.ano FROM u_attempts a JOIN items i ON i.id=a.item_id JOIN exams e ON e.id=i.exam_id WHERE a.user_id=? ORDER BY a.id', (u['id'],)).fetchall()
    rv = c.execute('SELECT nota,em FROM u_reviews WHERE user_id=?', (u['id'],)).fetchall()
    tot, ac = len(rs), sum(r['correta'] for r in rs)
    tempos = [r['tempo_ms'] for r in rs if r['tempo_ms'] and 0 < r['tempo_ms'] <= 600000]   # ignora pausas > 10 min
    def agg(key):
        d = {}
        for r in rs:
            x = d.setdefault(r[key], [0, 0]); x[0] += 1; x[1] += r['correta']
        return [{'nome': k, 'n': v[0], 'acertos': v[1], 'pct': round(100 * v[1] / v[0])} for k, v in sorted(d.items(), key=lambda kv: (-kv[1][0], str(kv[0])))]
    dia = lambda t: datetime.date.fromtimestamp(t)
    hoje = datetime.date.today(); ini = hoje - datetime.timedelta(days=(hoje.weekday() + 1) % 7)
    semanas = []
    for i in range(7, -1, -1):
        a = ini - datetime.timedelta(days=7 * i); b = a + datetime.timedelta(days=6)
        x = [r['correta'] for r in rs if a <= dia(r['em']) <= b]
        semanas.append({'rotulo': a.strftime('%d/%m'), 'n': len(x), 'acertos': sum(x)})
    meses = []
    for i in range(5, -1, -1):
        y, m = hoje.year, hoje.month - i
        while m <= 0: y -= 1; m += 12
        x = [r['correta'] for r in rs if dia(r['em']).year == y and dia(r['em']).month == m]
        meses.append({'rotulo': f'{m:02d}/{y}', 'n': len(x), 'acertos': sum(x)})
    dias = {dia(r['em']) for r in rs} | {dia(r['em']) for r in rv}
    seq, d = 0, hoje if hoje in dias else hoje - datetime.timedelta(days=1)
    while d in dias: seq += 1; d -= datetime.timedelta(days=1)
    last = {}
    for r in rs: last[r['item_id']] = r['correta']
    cards_total = c.execute('SELECT COUNT(*) FROM cards WHERE user_id=?', (u['id'],)).fetchone()[0]
    cards_hoje = c.execute('SELECT COUNT(*) FROM cards WHERE user_id=? AND due<=?', (u['id'], int(time.time()))).fetchone()[0]
    return {'respondidas': tot, 'acertos': ac, 'erros': tot - ac, 'pct': round(100 * ac / tot) if tot else 0,
            'tempo_medio_s': round(sum(tempos) / len(tempos) / 1000, 1) if tempos else None,
            'por_disciplina': agg('disciplina'), 'por_ano': agg('ano'), 'semanas': semanas, 'meses': meses, 'sequencia_dias': seq,
            'erros_pendentes': sum(1 for v in last.values() if v == 0), 'itens_distintos': len(last),
            'cards': {'total': cards_total, 'hoje': cards_hoje, 'revisoes': len(rv), 'bom_ou_facil': sum(1 for r in rv if r['nota'] >= 2)}}


def init():
    c = db(); c.executescript(SCHEMA)
    if 'janela_ini' not in [r['name'] for r in c.execute('PRAGMA table_info(users)')]:
        c.execute('ALTER TABLE users ADD COLUMN janela_ini INTEGER')
    if 'importante' not in [r['name'] for r in c.execute('PRAGMA table_info(blocks)')]:   # migração de bancos antigos
        c.execute('ALTER TABLE blocks ADD COLUMN importante INTEGER DEFAULT 0')
    c.commit(); c.close()


class H(BaseHTTPRequestHandler):
    server_version = 'CACDPlat/1'

    def log_message(self, *a): pass

    def send_j(self, code, obj, cookie=None):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        if cookie: self.send_header('Set-Cookie', cookie)
        self.end_headers(); self.wfile.write(body)

    def user(self, c):
        m = re.search(r'sid=([0-9a-f]+)', self.headers.get('Cookie') or '')
        if not m: return None
        r = c.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.exp>?', (m.group(1), time.time())).fetchone()
        return dict(r) if r else None

    def cookie(self, tok, age):
        sec = '; Secure' if os.environ.get('SECURE_COOKIE') == '1' else ''
        return f'sid={tok}; HttpOnly; SameSite=Lax; Path=/; Max-Age={age}{sec}'

    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        try: return json.loads(self.rfile.read(n) or b'{}') if n else {}
        except Exception: return {}

    # ---------------- GET ----------------
    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query); c = db()
        try:
            if not u.path.startswith('/api/'):
                p = 'index.html' if u.path in ('/', '') else u.path.lstrip('/')
                fp = os.path.normpath(os.path.join(STATIC, p))
                if fp.startswith(STATIC) and os.path.isfile(fp):
                    b = open(fp, 'rb').read(); self.send_response(200)
                    self.send_header('Content-Type', 'text/html; charset=utf-8' if fp.endswith('.html') else 'application/octet-stream')
                    self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b); return
                return self.send_j(404, {'erro': 'não encontrado'})
            me = self.user(c)
            if u.path == '/api/me':
                if not me: return self.send_j(200, {'logado': False})
                qn, rn = usage(c, me)
                return self.send_j(200, {'logado': True, 'nome': me['nome'], 'email': me['email'], 'role': me['role'], 'perfil': role_label(me),
                                         'acesso_ate': me['acesso_ate'], 'ilimitado': unlimited(me), 'uso': {'q': qn, 'c': rn}, 'limite': FREE, 'pix': mp_on(), 'preco': PRECO, 'renova_em': (janela_ativa(me) + JANELA) if janela_ativa(me) else None, 'wa': WA, 'materias': MATERIAS})
            if not me: return self.send_j(401, {'erro': 'login necessário'})
            if u.path == '/api/meta':
                anos = [r['ano'] for r in rows(c, "SELECT DISTINCT e.ano FROM exams e JOIN items i ON i.exam_id=e.id WHERE i.gabarito_status IN ('VALIDA','ALTERADA') ORDER BY 1 DESC")]
                disc = [r['disciplina'] for r in rows(c, "SELECT DISTINCT disciplina FROM items WHERE disciplina IS NOT NULL AND gabarito_status IN ('VALIDA','ALTERADA') ORDER BY 1")]
                return self.send_j(200, {'anos': anos, 'disciplinas': disc})
            if u.path == '/api/questions':
                w, p = ["i.gabarito_status IN ('VALIDA','ALTERADA')"], []
                if q.get('ano'): w.append('e.ano=?'); p.append(int(q['ano'][0]))
                if q.get('disciplina'): w.append('i.disciplina=?'); p.append(q['disciplina'][0])
                m = (q.get('meu') or [''])[0]
                if m == 'inedita': w.append('NOT EXISTS (SELECT 1 FROM u_attempts a WHERE a.item_id=i.id AND a.user_id=%d)' % me['id'])
                elif m == 'errei': w.append('(SELECT a.correta FROM u_attempts a WHERE a.item_id=i.id AND a.user_id=%d ORDER BY a.id DESC LIMIT 1)=0' % me['id'])
                elif m == 'acertei': w.append('(SELECT COUNT(*) FROM u_attempts a WHERE a.item_id=i.id AND a.user_id=%d AND a.correta=1)>=2' % me['id'])
                order = 'RANDOM()' if q.get('ordem', [''])[0] == 'aleatoria' else 'e.ano DESC, i.id'
                r = rows(c, f"SELECT i.id FROM items i JOIN exams e ON e.id=i.exam_id WHERE {' AND '.join(w)} ORDER BY {order} LIMIT 2000", *p)
                return self.send_j(200, {'ids': [x['id'] for x in r]})
            m = re.match(r'^/api/item/(\d+)$', u.path)
            if m:
                it = item_row(c, int(m.group(1)))
                return self.send_j(200 if it else 404, it or {'erro': 'item não encontrado'})
            if u.path == '/api/decks':
                now = int(time.time())
                return self.send_j(200, rows(c, 'SELECT deck, COUNT(*) total, SUM(due<=?) hoje FROM cards WHERE user_id=? GROUP BY deck ORDER BY deck', now, me['id']))
            if u.path == '/api/cards':
                d = (q.get('deck') or [''])[0]
                if q.get('due', ['0'])[0] == '1':
                    return self.send_j(200, rows(c, 'SELECT * FROM cards WHERE user_id=? AND deck=? AND due<=? ORDER BY reps DESC, due LIMIT 200', me['id'], d, int(time.time())))
                return self.send_j(200, rows(c, 'SELECT * FROM cards WHERE user_id=? AND deck=? ORDER BY id DESC LIMIT 500', me['id'], d))
            if u.path == '/api/notebooks':
                return self.send_j(200, rows(c, 'SELECT * FROM notebooks WHERE user_id=? ORDER BY id', me['id']))
            m = re.match(r'^/api/notebook/(\d+)$', u.path)
            if m:
                nb = c.execute('SELECT * FROM notebooks WHERE id=? AND user_id=?', (int(m.group(1)), me['id'])).fetchone()
                if not nb: return self.send_j(404, {'erro': 'caderno não encontrado'})
                return self.send_j(200, {'caderno': dict(nb), 'blocos': rows(c, 'SELECT id,parent_id,pos,texto,aberto,importante FROM blocks WHERE notebook_id=? ORDER BY pos,id', nb['id'])})
            if u.path == '/api/pix/status':
                pg = c.execute('SELECT * FROM pagamentos WHERE id=? AND user_id=?', (int((q.get('id') or ['0'])[0]), me['id'])).fetchone()
                if not pg: return self.send_j(404, {'erro': 'pagamento não encontrado'})
                st = confirmar_pagamento(c, dict(pg)); t = c.execute('SELECT acesso_ate FROM users WHERE id=?', (me['id'],)).fetchone()
                return self.send_j(200, {'status': st, 'acesso_ate': t['acesso_ate']})
            if u.path == '/api/admin/pagamentos':
                if me['role'] != 'master': return self.send_j(403, {'erro': 'somente o Master'})
                return self.send_j(200, rows(c, 'SELECT p.id,p.valor,p.status,p.criado_em,p.pago_em,u.nome,u.email FROM pagamentos p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 200'))
            if u.path == '/api/dashboard':
                return self.send_j(200, dashboard(c, me))
            if u.path == '/api/revisao':
                if premium_only(me): return self.send_j(403, premium_only(me))
                nb = c.execute('SELECT * FROM notebooks WHERE id=? AND user_id=?', (int((q.get('notebook_id') or ['0'])[0]), me['id'])).fetchone()
                if not nb: return self.send_j(404, {'erro': 'caderno não encontrado'})
                bl = dfs_order(rows(c, 'SELECT id,parent_id,pos,texto,importante FROM blocks WHERE notebook_id=? ORDER BY pos,id', nb['id']))
                byid = {b['id']: b for b in bl}
                imp = [b for b in bl if b['importante'] and b['texto'].strip()]
                if imp: modo, pool = 'importantes', imp
                else:
                    modo, pool = 'aleatorio', [b for b in bl if b['texto'].strip()]; random.shuffle(pool); pool = pool[:20]
                return self.send_j(200, {'modo': modo, 'caderno': nb['nome'], 'itens': [{'id': b['id'], 'texto': b['texto'], 'contexto': ancestors(byid, b)} for b in pool]})
            if u.path == '/api/agenda':
                de, ate = (q.get('de') or [''])[0], (q.get('ate') or [''])[0]
                try: return self.send_j(200, week_events(c, me['id'], de, ate))
                except ValueError: return self.send_j(400, {'erro': 'datas inválidas'})
            if u.path == '/api/cursos':
                return self.send_j(200, rows(c, 'SELECT * FROM cursos ORDER BY materia, ordem, id'))
            if u.path == '/api/admin/users':
                if me['role'] != 'master': return self.send_j(403, {'erro': 'somente o Master'})
                us = rows(c, 'SELECT id,nome,email,role,acesso_ate,criado_em,ultimo_login,janela_ini FROM users ORDER BY id')
                for x in us:
                    x['q'], x['c'] = usage(c, x); x['ilimitado'] = unlimited(x)
                return self.send_j(200, us)
            if u.path == '/api/admin/backup':
                if me['role'] != 'master': return self.send_j(403, {'erro': 'somente o Master'})
                tf = tempfile.NamedTemporaryFile(suffix='.db', delete=False); tf.close()
                dst = sqlite3.connect(tf.name); c.backup(dst); dst.close()
                data = open(tf.name, 'rb').read(); os.unlink(tf.name)
                self.send_response(200); self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', 'attachment; filename="cacd_backup_%s.db"' % time.strftime('%Y%m%d_%H%M'))
                self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data); return
            return self.send_j(404, {'erro': 'rota inexistente'})
        finally:
            c.close()

    # ---------------- POST ----------------
    def do_POST(self):
        u = urlparse(self.path); d = self.body(); c = db()
        try:
            if u.path == '/api/signup':
                nome, email, pw = str(d.get('nome', '')).strip(), str(d.get('email', '')).strip().lower(), str(d.get('senha', ''))
                if len(nome) < 2 or not re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email) or len(pw) < 8:
                    return self.send_j(400, {'erro': 'Informe nome, e-mail válido e senha com 8+ caracteres.'})
                if c.execute('SELECT 1 FROM users WHERE email=?', (email,)).fetchone():
                    return self.send_j(409, {'erro': 'Este e-mail já está cadastrado.'})
                first = c.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 0
                me_env = (os.environ.get('MASTER_EMAIL') or '').strip().lower()
                role = 'master' if (email == me_env if me_env else first) else 'iniciante'   # com MASTER_EMAIL definido, só esse e-mail vira Master
                uid = c.execute('INSERT INTO users(nome,email,pw,role,criado_em,ultimo_login) VALUES(?,?,?,?,?,?)', (nome, email, hash_pw(pw), role, int(time.time()), int(time.time()))).lastrowid
                for mt in MATERIAS: c.execute('INSERT INTO notebooks(user_id,nome,materia) VALUES(?,?,?)', (uid, mt, mt))
                tok = secrets.token_hex(24); c.execute('INSERT INTO sessions VALUES(?,?,?)', (tok, uid, time.time() + 30 * DAY)); c.commit()
                return self.send_j(200, {'ok': True}, self.cookie(tok, 30 * DAY))
            if u.path == '/api/login':
                email = str(d.get('email', '')).strip().lower()
                f = FAILS.get(email, (0, 0))
                if f[0] >= 5 and time.time() < f[1]: return self.send_j(429, {'erro': 'Muitas tentativas. Aguarde 1 minuto.'})
                r = c.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
                if not r or not check_pw(str(d.get('senha', '')), r['pw']):
                    FAILS[email] = (f[0] + 1, time.time() + 60)
                    return self.send_j(401, {'erro': 'E-mail ou senha incorretos.'})
                FAILS.pop(email, None)
                tok = secrets.token_hex(24); c.execute('INSERT INTO sessions VALUES(?,?,?)', (tok, r['id'], time.time() + 30 * DAY))
                c.execute('UPDATE users SET ultimo_login=? WHERE id=?', (int(time.time()), r['id'])); c.commit()
                return self.send_j(200, {'ok': True}, self.cookie(tok, 30 * DAY))
            if u.path == '/api/logout':
                m = re.search(r'sid=([0-9a-f]+)', self.headers.get('Cookie') or '')
                if m: c.execute('DELETE FROM sessions WHERE token=?', (m.group(1),)); c.commit()
                return self.send_j(200, {'ok': True}, self.cookie('', 0))
            if u.path == '/api/pix/webhook':   # aviso do Mercado Pago (sem login); a liberação só ocorre após consultar o pagamento na API
                qs = parse_qs(u.query); data_id = (qs.get('data.id') or [''])[0] or str((d.get('data') or {}).get('id', ''))
                if not data_id: return self.send_j(200, {'ok': True})
                if re.search(r'[A-Z]', data_id): data_id = data_id.lower()
                if not assinatura_valida({k.lower(): v for k, v in self.headers.items()}, data_id): return self.send_j(401, {'erro': 'assinatura inválida'})
                pg = c.execute('SELECT * FROM pagamentos WHERE mp_id=?', (data_id,)).fetchone()
                if pg: confirmar_pagamento(c, dict(pg))
                return self.send_j(200, {'ok': True})
            me = self.user(c)
            if not me: return self.send_j(401, {'erro': 'login necessário'})
            P = u.path
            if P == '/api/pix/criar':
                if not mp_on(): return self.send_j(503, {'erro': 'Pagamento por Pix ainda não está configurado. Fale com o gestor.'})
                if me['role'] == 'master': return self.send_j(400, {'erro': 'O Master não precisa assinar.'})
                ex = c.execute("SELECT * FROM pagamentos WHERE user_id=? AND status='pendente' AND expira_em>? ORDER BY id DESC LIMIT 1", (me['id'], int(time.time()))).fetchone()
                if ex: return self.send_j(200, {'id': ex['id'], 'qr_code': ex['qr_code'], 'qr_src': ex['qr_src'], 'valor': ex['valor'], 'expira_em': ex['expira_em']})
                exp = int(time.time()) + 1800
                pid = c.execute('INSERT INTO pagamentos(user_id,valor,status,criado_em,expira_em) VALUES(?,?,?,?,?)', (me['id'], PRECO, 'pendente', int(time.time()), exp)).lastrowid
                body = {'transaction_amount': PRECO, 'description': 'CACD Study – assinatura de 30 dias', 'payment_method_id': 'pix', 'payer': {'email': me['email']},
                        'external_reference': f'cacd-{pid}', 'date_of_expiration': (datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3))) + datetime.timedelta(minutes=30)).isoformat(timespec='milliseconds')}
                if os.environ.get('PUBLIC_URL'): body['notification_url'] = os.environ['PUBLIC_URL'].rstrip('/') + '/api/pix/webhook'
                try:
                    r = mp_req('POST', '/v1/payments', body, idem=f'cacd-{pid}')
                    td = r['point_of_interaction']['transaction_data']
                    src = 'data:image/png;base64,' + td['qr_code_base64']
                    c.execute('UPDATE pagamentos SET mp_id=?, qr_code=?, qr_src=? WHERE id=?', (str(r['id']), td['qr_code'], src, pid)); c.commit()
                    return self.send_j(200, {'id': pid, 'qr_code': td['qr_code'], 'qr_src': src, 'valor': PRECO, 'expira_em': exp})
                except Exception as e:
                    print('Erro Mercado Pago:', repr(e)[:300]); c.execute('DELETE FROM pagamentos WHERE id=?', (pid,)); c.commit()
                    return self.send_j(502, {'erro': 'Não foi possível gerar o Pix agora. Tente de novo ou fale com o gestor.'})
            if P == '/api/answer':
                if not allowed(c, me, 'q'): return self.send_j(402, {'paywall': True})
                start_window(c, me)
                iid, resp = int(d['item_id']), str(d['resposta']).upper()
                it = item_row(c, iid); ck = current_key(c, iid)
                if resp not in ('C', 'E') or not it or not ck or it['gabarito_status'] not in ('VALIDA', 'ALTERADA'):
                    return self.send_j(400, {'erro': 'item indisponível'})
                ok = ck['resposta'] == resp
                c.execute('INSERT INTO u_attempts(user_id,item_id,resposta,correta,tempo_ms,em) VALUES(?,?,?,?,?,?)', (me['id'], iid, resp, int(ok), d.get('tempo_ms'), int(time.time())))
                chaves = rows(c, 'SELECT versao,resposta,fonte,motivo,vigente FROM answer_keys WHERE item_id=? ORDER BY id', iid)
                n, modo = (make_cards(c, me, iid, ck['resposta']) if not ok else (0, ''))
                c.commit()
                return self.send_j(200, {'correta': ok, 'gabarito': ck['resposta'], 'minha_resposta': resp, 'chaves': chaves, 'cards_criados': n, 'cards_modo': modo})
            if P == '/api/gerar_cards':
                iid = int(d['item_id']); ck = current_key(c, iid)
                if not ck: return self.send_j(400, {'erro': 'item sem gabarito'})
                n, modo = make_cards(c, me, iid, ck['resposta'], force=True); c.commit()
                return self.send_j(200, {'cards_criados': n, 'cards_modo': modo})
            if P == '/api/card':
                if not str(d.get('frente', '')).strip() or not str(d.get('verso', '')).strip(): return self.send_j(400, {'erro': 'preencha frente e verso'})
                c.execute('INSERT INTO cards(user_id,deck,frente,verso,origem,criado_em) VALUES(?,?,?,?,?,?)', (me['id'], str(d.get('deck') or 'Meus cartões'), d['frente'], d['verso'], 'manual', int(time.time()))); c.commit()
                return self.send_j(200, {'ok': True})
            if P == '/api/card/delete':
                c.execute('DELETE FROM cards WHERE id=? AND user_id=?', (int(d['id']), me['id'])); c.commit(); return self.send_j(200, {'ok': True})
            if P == '/api/card/review':
                if not allowed(c, me, 'c'): return self.send_j(402, {'paywall': True})
                start_window(c, me)
                cd = c.execute('SELECT * FROM cards WHERE id=? AND user_id=?', (int(d['id']), me['id'])).fetchone()
                if not cd: return self.send_j(404, {'erro': 'cartão não encontrado'})
                nota = int(d['nota']); e, v, l = sm2(dict(cd), nota)
                due = int(time.time()) + (600 if v == 0 else v * DAY)
                c.execute('UPDATE cards SET ease=?,ivl=?,due=?,lapsos=lapsos+?,reps=? WHERE id=?', (e, v, due, l, 0 if nota == 0 else cd['reps'] + 1, cd['id']))
                c.execute('INSERT INTO u_reviews(user_id,card_id,nota,em) VALUES(?,?,?,?)', (me['id'], cd['id'], nota, int(time.time()))); c.commit()
                return self.send_j(200, {'ok': True, 'proxima_em': due})
            if P == '/api/notebook':
                nome = str(d.get('nome', '')).strip()
                if not nome: return self.send_j(400, {'erro': 'informe o nome'})
                nid = c.execute('INSERT INTO notebooks(user_id,nome,materia) VALUES(?,?,?)', (me['id'], nome, d.get('materia') or 'Outros')).lastrowid; c.commit()
                return self.send_j(200, {'id': nid})
            if P in ('/api/block', '/api/block/update', '/api/block/move', '/api/block/delete'):
                if P == '/api/block':
                    nb = c.execute('SELECT * FROM notebooks WHERE id=? AND user_id=?', (int(d['notebook_id']), me['id'])).fetchone()
                    if not nb: return self.send_j(404, {'erro': 'caderno não encontrado'})
                    par = d.get('parent_id')
                    if par is not None and not c.execute('SELECT 1 FROM blocks WHERE id=? AND notebook_id=?', (par, nb['id'])).fetchone(): return self.send_j(400, {'erro': 'bloco pai inválido'})
                    sib = siblings(c, nb['id'], par); after = d.get('after_id')
                    bid = c.execute('INSERT INTO blocks(notebook_id,user_id,parent_id,texto) VALUES(?,?,?,?)', (nb['id'], me['id'], par, d.get('texto', ''))).lastrowid
                    sib = [x for x in sib]
                    sib.insert(sib.index(after) + 1 if after in sib else len(sib), bid); renumber(c, sib)
                    if '::' in d.get('texto', ''): sync_block_card(c, me, dict(nb), bid, d['texto'])
                    c.commit(); return self.send_j(200, {'id': bid})
                b = c.execute('SELECT b.*, n.nome AS nbnome FROM blocks b JOIN notebooks n ON n.id=b.notebook_id WHERE b.id=? AND b.user_id=?', (int(d['id']), me['id'])).fetchone()
                if not b: return self.send_j(404, {'erro': 'bloco não encontrado'})
                if P == '/api/block/update':
                    if 'texto' in d:
                        c.execute('UPDATE blocks SET texto=? WHERE id=?', (str(d['texto']), b['id'])); sync_block_card(c, me, {'nome': b['nbnome']}, b['id'], str(d['texto']))
                    if 'aberto' in d: c.execute('UPDATE blocks SET aberto=? WHERE id=?', (int(bool(d['aberto'])), b['id']))
                    if 'importante' in d: c.execute('UPDATE blocks SET importante=? WHERE id=?', (int(bool(d['importante'])), b['id']))
                elif P == '/api/block/delete':
                    ids = descendants(c, b['id'])
                    for x in ids: c.execute('DELETE FROM cards WHERE block_id=? AND user_id=?', (x, me['id'])); c.execute('DELETE FROM blocks WHERE id=?', (x,))
                    renumber(c, siblings(c, b['notebook_id'], b['parent_id']))
                else:
                    ac, sib = d.get('acao'), siblings(c, b['notebook_id'], b['parent_id'])
                    i = sib.index(b['id'])
                    if ac in ('up', 'down'):
                        j = i - 1 if ac == 'up' else i + 1
                        if 0 <= j < len(sib): sib[i], sib[j] = sib[j], sib[i]; renumber(c, sib)
                    elif ac == 'indent' and i > 0:
                        newp = sib[i - 1]; sib.remove(b['id']); renumber(c, sib)
                        ns = siblings(c, b['notebook_id'], newp); ns.append(b['id'])
                        c.execute('UPDATE blocks SET parent_id=? WHERE id=?', (newp, b['id'])); renumber(c, ns)
                        c.execute('UPDATE blocks SET aberto=1 WHERE id=?', (newp,))
                    elif ac == 'outdent' and b['parent_id'] is not None:
                        par = c.execute('SELECT * FROM blocks WHERE id=?', (b['parent_id'],)).fetchone()
                        sib.remove(b['id']); renumber(c, sib)
                        ns = siblings(c, b['notebook_id'], par['parent_id']); ns.insert(ns.index(par['id']) + 1, b['id'])
                        c.execute('UPDATE blocks SET parent_id=? WHERE id=?', (par['parent_id'], b['id'])); renumber(c, ns)
                c.commit(); return self.send_j(200, {'ok': True})
            if P == '/api/block/flashcard':
                if premium_only(me): return self.send_j(403, premium_only(me))
                b = c.execute('SELECT b.*, n.nome AS nbnome FROM blocks b JOIN notebooks n ON n.id=b.notebook_id WHERE b.id=? AND b.user_id=?', (int(d['id']), me['id'])).fetchone()
                if not b or not b['texto'].strip(): return self.send_j(404, {'erro': 'bloco não encontrado ou vazio'})
                bl = rows(c, 'SELECT id,parent_id,texto FROM blocks WHERE notebook_id=?', b['notebook_id']); byid = {x['id']: x for x in bl}
                f, v, modo = smart_card(b['texto'], ancestors(byid, dict(b)))
                c.execute("DELETE FROM cards WHERE user_id=? AND block_id=?", (me['id'], b['id']))
                c.execute('INSERT INTO cards(user_id,deck,frente,verso,origem,block_id,criado_em) VALUES(?,?,?,?,?,?,?)',
                          (me['id'], b['nbnome'], f, v, 'revisao', b['id'], int(time.time()))); c.commit()
                return self.send_j(200, {'ok': True, 'deck': b['nbnome'], 'frente': f, 'verso': v, 'modo': modo})
            if P in ('/api/agenda', '/api/agenda/delete'):
                if P == '/api/agenda/delete':
                    c.execute('DELETE FROM agenda WHERE id=? AND user_id=?', (int(d['id']), me['id'])); c.commit(); return self.send_j(200, {'ok': True})
                vals, err = agenda_clean(d)
                if err: return self.send_j(400, {'erro': err})
                if d.get('id'):
                    if not c.execute('SELECT 1 FROM agenda WHERE id=? AND user_id=?', (int(d['id']), me['id'])).fetchone(): return self.send_j(404, {'erro': 'compromisso não encontrado'})
                    c.execute('UPDATE agenda SET titulo=?,data=?,inicio=?,fim=?,categoria=?,notas=?,repete=? WHERE id=?', (*vals, int(d['id'])))
                else: c.execute('INSERT INTO agenda(user_id,titulo,data,inicio,fim,categoria,notas,repete) VALUES(?,?,?,?,?,?,?,?)', (me['id'], *vals))
                c.commit(); return self.send_j(200, {'ok': True})
            if P in ('/api/curso', '/api/curso/delete', '/api/admin/user'):
                if me['role'] != 'master': return self.send_j(403, {'erro': 'somente o Master'})
                if P == '/api/curso/delete':
                    c.execute('DELETE FROM cursos WHERE id=?', (int(d['id']),))
                elif P == '/api/curso':
                    url = str(d.get('url', '')).strip()
                    if not re.match(r'^https?://', url) or not str(d.get('titulo', '')).strip(): return self.send_j(400, {'erro': 'informe título e um link começando com http(s)://'})
                    if d.get('id'): c.execute('UPDATE cursos SET materia=?,titulo=?,descricao=?,url=? WHERE id=?', (d.get('materia', ''), d['titulo'], d.get('descricao', ''), url, int(d['id'])))
                    else: c.execute('INSERT INTO cursos(materia,titulo,descricao,url) VALUES(?,?,?,?)', (d.get('materia', ''), d['titulo'], d.get('descricao', ''), url))
                else:
                    uid, ac = int(d['id']), d.get('acao')
                    t = c.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
                    if not t: return self.send_j(404, {'erro': 'usuário não encontrado'})
                    if t['id'] == me['id'] and ac in ('bloquear', 'iniciante'): return self.send_j(400, {'erro': 'você não pode rebaixar a si mesmo'})
                    if ac in ('liberar30', 'liberar90'):
                        base = max(time.time(), t['acesso_ate']); dias = 30 if ac == 'liberar30' else 90
                        c.execute("UPDATE users SET role=CASE WHEN role='master' THEN 'master' ELSE 'quarto' END, acesso_ate=? WHERE id=?", (int(base + dias * DAY), uid))
                    elif ac == 'bloquear': c.execute("UPDATE users SET role='iniciante', acesso_ate=0 WHERE id=?", (uid,))
                    elif ac in ('master', 'iniciante', 'quarto'): c.execute('UPDATE users SET role=? WHERE id=?', (ac, uid))
                    else: return self.send_j(400, {'erro': 'ação inválida'})
                c.commit(); return self.send_j(200, {'ok': True})
            return self.send_j(404, {'erro': 'rota inexistente'})
        except (KeyError, ValueError) as e:
            return self.send_j(400, {'erro': f'dados inválidos: {e}'})
        finally:
            c.close()


def main():
    if not os.path.exists(DB_PATH):   # primeira execução (ex.: disco novo na hospedagem): copia o banco inicial de questões
        seed = os.environ.get('SEED_DB', os.path.join(ROOT, 'data', 'seed.db'))
        if not os.path.exists(seed): sys.exit('Banco não encontrado. Rode: python3 importer/build_db.py')
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True); shutil.copy(seed, DB_PATH); print('Banco inicial copiado para', DB_PATH)
    init()
    host, port = os.environ.get('HOST', '127.0.0.1'), int(os.environ.get('PORT', '8765'))
    print(f'CACD Study (plataforma) em http://localhost:{port}  – o PRIMEIRO cadastro vira Master.')
    ThreadingHTTPServer((host, port), H).serve_forever()


if __name__ == '__main__':
    main()
