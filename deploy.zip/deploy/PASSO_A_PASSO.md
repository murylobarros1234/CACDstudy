# Colocar o CACD Study no ar (Render) – passo a passo

Custo: o plano com disco persistente (necessário para não perder cadastros) é pago. Em novembro/2026 o plano "Starter" custava a partir de US$ 7/mês e o disco US$ 0,25 por GB/mês. CONFIRME os valores em render.com/pricing antes de contratar.
NÃO use o plano gratuito: ele dorme após 15 min sem uso e não tem disco, então os cadastros seriam apagados.

## 1. GitHub (guarda o código)
1. Crie uma conta em github.com.
2. Clique em "New repository". Nome: cacd-study. Marque **Private** (privado). Create repository.
3. Clique em "uploading an existing file" e arraste TODO o conteúdo desta pasta `deploy` (as pastas app e data e os arquivos render.yaml, requirements.txt, .gitignore). Clique em "Commit changes".

## 2. Render (coloca no ar)
1. Crie uma conta em render.com e entre com o GitHub.
2. Clique em "New +" > "Blueprint" e escolha o repositório cacd-study.
3. Quando pedir **MASTER_EMAIL**, digite o e-mail que você vai usar para se cadastrar como gestor. Só esse e-mail vira Master.
4. Confirme o plano pago (Starter) e clique em "Apply". Aguarde o deploy terminar.
5. A Render mostra o endereço (algo como https://cacd-study.onrender.com). Abra.

## 3. Primeiro acesso
1. Clique em "Criar conta" e cadastre-se **com o e-mail do MASTER_EMAIL**. Você entra como Master.
2. Teste: crie uma segunda conta em aba anônima (Iniciante), responda 5 questões e veja o bloqueio.
3. Em Administração, use "Baixar backup do banco de dados" regularmente (por exemplo, toda semana).

## Opcional: IA para 4–5 flashcards por questão
No painel da Render: seu serviço > Environment > Add Environment Variable: `ANTHROPIC_API_KEY` = sua chave. (Pago por uso; não testado com a API real.)

## Se algo der errado
Na Render, abra o serviço > Logs, copie as últimas linhas e me envie.

## Pix com liberação automática (Mercado Pago)
Faça isso DEPOIS de o site estar no ar. Os nomes das telas do Mercado Pago podem mudar; na dúvida, siga a documentação deles (mercadopago.com.br/developers).
1. No Mercado Pago, abra "Suas integrações" (painel de desenvolvedores) e crie uma aplicação para pagamentos online (Checkout API / Pix).
2. Copie o **Access Token de produção** (começa com APP_USR-). Se pedirem para ativar as credenciais de produção, complete o que for solicitado. Não confirmei se uma conta de CPF consegue; se não conseguir, a conta precisará de outro tipo de cadastro.
3. Na aplicação, abra "Webhooks", em modo produção: URL `https://SEU-ENDEREÇO/api/pix/webhook`, evento **Pagamentos**. Copie a **assinatura secreta**.
4. Na Render (seu serviço > Environment) crie: `MP_ACCESS_TOKEN` (o token), `MP_WEBHOOK_SECRET` (a assinatura secreta) e `PUBLIC_URL` (`https://SEU-ENDEREÇO`). Guarde o token só aí: nunca o envie a ninguém nem o coloque no GitHub.
5. TESTE REAL: crie temporariamente `PRECO` = `1.00`, faça uma conta de teste e pague o Pix de R$ 1,00 com **outra** conta bancária. Confirme que o acesso foi liberado sozinho e que o pagamento aparece em Administração. Depois **apague a variável PRECO** (volta a R$ 39,90).
6. Só então divulgue. Confira no Mercado Pago a tarifa por Pix e como o dinheiro é repassado para você.
